-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 22, 2021 at 11:19 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `NFC_ID` int(11) NOT NULL,
  `Name` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `Surname` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `BirthDate` date NOT NULL,
  `IDDocument` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `TypeOfDocument` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `DateOfIssue` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`NFC_ID`, `Name`, `Surname`, `BirthDate`, `IDDocument`, `TypeOfDocument`, `DateOfIssue`) VALUES
(1, 'Vasiliki', 'Kantere', '1990-05-21', 'AM123456', 'identity', '2010-01-01'),
(2, 'Maria', 'Krommuda', '1990-06-21', 'AK123456', 'identity', '2010-02-02'),
(3, 'Konstantinos', 'Tzamaloukas', '1985-08-21', 'AM234567', 'identity', '2010-03-03'),
(4, 'Katerina', 'Doka', '1985-05-21', 'AK234567', 'identity', '2010-04-04'),
(5, 'Konstantinos', 'Sagonas', '1980-09-21', 'AM345678', 'identity', '2010-05-05'),
(6, 'Nektarios', 'Kozuris', '1980-10-21', 'AK345678', 'identity', '2010-06-06'),
(7, 'Panagiotis', 'Tsanakas', '1975-11-21', 'AM456789', 'identity', '2010-07-07'),
(8, 'Giorgos', 'Gkoumas', '1975-12-21', 'AK456789', 'identity', '2010-08-08'),
(9, 'Nikolaos', 'Papaspurou', '1965-09-21', 'AK000000', 'identity', '2010-09-09');

-- --------------------------------------------------------

--
-- Table structure for table `email`
--

CREATE TABLE `email` (
  `Email` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `NFC_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `email`
--

INSERT INTO `email` (`Email`, `NFC_ID`) VALUES
('verena@mail.ntua.gr', 1),
('mariakr@dblab.ece.ntua.gr', 2),
('kot@dblab.ece.ntua.gr', 3),
('katerinadoka@dblab.ece.ntua.gr', 4),
('kostis@cs.ntua.gr', 5),
('koz@softlab.ntua.gr', 6),
('panag@cs.ntua.gr', 7),
('goumas@cslab.ece.ntua.gr', 8),
('nickie@softlab.ntua.gr', 9);

-- --------------------------------------------------------

--
-- Table structure for table `happensin`
--

CREATE TABLE `happensin` (
  `ServiceID` int(11) NOT NULL,
  `RoomID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `happensin`
--

INSERT INTO `happensin` (`ServiceID`, `RoomID`) VALUES
(1, 10),
(1, 20),
(2, 60),
(2, 65),
(3, 30),
(4, 40),
(5, 100),
(5, 101),
(6, 50),
(6, 55);

-- --------------------------------------------------------

--
-- Table structure for table `hasaccess`
--

CREATE TABLE `hasaccess` (
  `NFC_ID` int(11) NOT NULL,
  `RoomID` int(11) NOT NULL,
  `StartTime` datetime NOT NULL DEFAULT current_timestamp(),
  `EndTime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `hasaccess`
--

INSERT INTO `hasaccess` (`NFC_ID`, `RoomID`, `StartTime`, `EndTime`) VALUES
(1, 70, '2010-01-01 09:00:20', '2010-01-10 09:00:20'),
(1, 10, '2010-01-02 16:20:30', '2010-01-10 09:00:20'),
(1, 20, '2010-01-02 16:20:30', '2010-01-10 09:00:20'),
(2, 80, '2010-02-02 10:00:00', '2010-02-12 10:00:00'),
(3, 40, '2010-03-10 10:24:30', '2010-03-20 13:00:00'),
(5, 50, '2010-05-08 19:20:40', '2010-05-20 10:20:40'),
(5, 55, '2010-05-08 19:20:40', '2010-05-20 10:20:40'),
(6, 40, '2010-06-13 16:45:35', '2010-06-19 19:45:00'),
(6, 90, '2010-06-06 16:45:35', '2010-06-15 19:45:00'),
(1, 70, '2010-01-01 09:00:20', '2010-01-10 09:00:20'),
(1, 10, '2010-01-02 16:20:30', '2010-01-10 09:00:20'),
(1, 20, '2010-01-02 16:20:30', '2010-01-10 09:00:20'),
(2, 80, '2010-02-02 10:00:00', '2010-02-12 10:00:00'),
(3, 40, '2010-03-10 10:24:30', '2010-03-20 13:00:00'),
(5, 50, '2010-05-08 19:20:40', '2010-05-20 10:20:40'),
(5, 55, '2010-05-08 19:20:40', '2010-05-20 10:20:40'),
(6, 40, '2010-06-13 16:45:35', '2010-06-19 19:45:00'),
(6, 90, '2010-06-06 16:45:35', '2010-06-15 19:45:00');

-- --------------------------------------------------------

--
-- Table structure for table `phone`
--

CREATE TABLE `phone` (
  `PhoneNumber` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `NFC_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `phone`
--

INSERT INTO `phone` (`PhoneNumber`, `NFC_ID`) VALUES
('6901234567', 1),
('6912345678', 2),
('6954637289', 3),
('6900000000', 4),
('6999637289', 5),
('6954637888', 6),
('6954636574', 7),
('6954637200', 8),
('6975649302', 9);

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `RoomID` int(11) NOT NULL,
  `RoomName` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `Description` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `Beds` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`RoomID`, `RoomName`, `Description`, `Beds`) VALUES
(10, 'big gym', 'east', 0),
(20, 'small gym', 'west', 0),
(30, 'hair salon', 'north', 0),
(40, 'shauna', 'west', 0),
(50, 'meeting room 1', 'east', 0),
(55, 'meeting room 2', 'east', 0),
(60, 'bar1', 'west', 0),
(65, 'bar2', 'east', 0),
(70, 'room1', 'north', 1),
(80, 'room2', 'west', 2),
(90, 'room3', 'east', 3),
(95, 'room4', 'south', 3),
(100, 'restaurant1', 'north', 0),
(101, 'restaurant2', 'south', 0);

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `ServiceID` int(11) NOT NULL,
  `ServiceDescription` text COLLATE utf8_unicode_ci NOT NULL,
  `RequiresSubscription` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`ServiceID`, `ServiceDescription`, `RequiresSubscription`) VALUES
(1, 'gym', 1),
(2, 'bar', 0),
(3, 'hair salon', 0),
(4, 'shauna', 1),
(5, 'restaurant', 0),
(6, 'meeting room', 1);

-- --------------------------------------------------------

--
-- Table structure for table `subscribes`
--

CREATE TABLE `subscribes` (
  `NFC_ID` int(11) NOT NULL,
  `ServiceID` int(11) NOT NULL,
  `DateTime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `subscribes`
--

INSERT INTO `subscribes` (`NFC_ID`, `ServiceID`, `DateTime`) VALUES
(1, 1, '2010-01-02 16:20:30'),
(1, 6, '2010-01-02 16:21:30'),
(2, 1, '2010-02-05 11:33:30'),
(3, 4, '2010-03-10 10:24:30'),
(3, 6, '2010-03-11 10:25:30'),
(4, 1, '2010-04-12 22:12:33'),
(5, 4, '2010-05-08 18:20:50'),
(5, 6, '2010-05-08 19:20:40'),
(6, 4, '2010-06-13 16:45:35'),
(8, 1, '2010-08-16 09:09:37'),
(9, 1, '2010-09-10 10:11:12');

-- --------------------------------------------------------

--
-- Table structure for table `used`
--

CREATE TABLE `used` (
  `DateTime` datetime NOT NULL DEFAULT current_timestamp(),
  `ServiceID` int(11) NOT NULL,
  `NFC_ID` int(11) NOT NULL,
  `Price` int(11) NOT NULL,
  `Description` text COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `used`
--

INSERT INTO `used` (`DateTime`, `ServiceID`, `NFC_ID`, `Price`, `Description`) VALUES
('2010-01-03 19:00:00', 1, 1, 5, 'small gym'),
('2010-01-05 10:00:00', 6, 1, 50, 'meeting room 1'),
('2010-02-06 12:33:30', 3, 2, 25, 'hair salon'),
('2010-02-07 11:30:00', 1, 2, 7, 'big gym'),
('2010-03-13 12:00:00', 4, 3, 20, 'shauna'),
('2010-03-15 10:00:00', 6, 3, 30, 'meeting room 2'),
('2010-04-14 07:30:00', 1, 4, 5, 'small gym'),
('2010-05-09 18:20:50', 4, 5, 20, 'shauna'),
('2010-05-16 18:20:50', 6, 5, 50, 'meeting room 1'),
('2010-06-13 18:40:30', 4, 6, 20, 'shauna'),
('2010-06-15 16:45:35', 5, 6, 40, 'restaurant1'),
('2010-07-13 16:45:35', 2, 7, 20, 'bar1'),
('2010-08-20 16:45:35', 1, 8, 7, 'big gym'),
('2010-09-11 10:00:12', 1, 9, 5, 'small gym'),
('2010-09-12 20:00:12', 5, 9, 25, 'restaurant2'),
('2010-09-12 22:11:12', 2, 9, 15, 'bar2');

-- --------------------------------------------------------

--
-- Table structure for table `visits`
--

CREATE TABLE `visits` (
  `NFC_ID` int(11) NOT NULL,
  `RoomID` int(11) NOT NULL,
  `EnterTime` datetime NOT NULL DEFAULT current_timestamp(),
  `ExitTime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `visits`
--

INSERT INTO `visits` (`NFC_ID`, `RoomID`, `EnterTime`, `ExitTime`) VALUES
(1, 10, '2021-06-22 11:29:10', '2021-06-22 12:28:24'),
(1, 50, '2021-06-22 13:54:59', '2021-06-22 18:40:59'),
(2, 30, '2021-06-22 11:29:10', '2021-06-22 13:28:24'),
(2, 50, '2021-06-22 13:54:59', '2021-06-22 18:30:59'),
(3, 40, '2021-06-22 11:45:17', '2021-06-22 17:44:34'),
(5, 10, '2021-06-22 09:44:34', '2021-06-22 11:44:34'),
(8, 50, '2021-06-22 13:20:59', '2021-06-22 18:54:59'),
(9, 50, '2021-06-22 13:30:59', '2021-06-22 18:50:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`NFC_ID`);

--
-- Indexes for table `email`
--
ALTER TABLE `email`
  ADD PRIMARY KEY (`Email`),
  ADD KEY `NFC_ID` (`NFC_ID`);

--
-- Indexes for table `happensin`
--
ALTER TABLE `happensin`
  ADD PRIMARY KEY (`ServiceID`,`RoomID`);

--
-- Indexes for table `hasaccess`
--
ALTER TABLE `hasaccess`
  ADD KEY `NFC_ID` (`NFC_ID`);

--
-- Indexes for table `phone`
--
ALTER TABLE `phone`
  ADD PRIMARY KEY (`PhoneNumber`),
  ADD KEY `NFC_ID` (`NFC_ID`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`RoomID`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`ServiceID`);

--
-- Indexes for table `subscribes`
--
ALTER TABLE `subscribes`
  ADD KEY `ServiceID` (`ServiceID`),
  ADD KEY `NFC_ID` (`NFC_ID`);

--
-- Indexes for table `used`
--
ALTER TABLE `used`
  ADD PRIMARY KEY (`DateTime`),
  ADD KEY `NFC_ID` (`NFC_ID`),
  ADD KEY `ServiceID` (`ServiceID`);

--
-- Indexes for table `visits`
--
ALTER TABLE `visits`
  ADD PRIMARY KEY (`NFC_ID`,`RoomID`,`EnterTime`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `email`
--
ALTER TABLE `email`
  ADD CONSTRAINT `email_ibfk_1` FOREIGN KEY (`NFC_ID`) REFERENCES `customer` (`NFC_ID`);

--
-- Constraints for table `hasaccess`
--
ALTER TABLE `hasaccess`
  ADD CONSTRAINT `hasaccess_ibfk_1` FOREIGN KEY (`NFC_ID`) REFERENCES `customer` (`NFC_ID`);

--
-- Constraints for table `phone`
--
ALTER TABLE `phone`
  ADD CONSTRAINT `phone_ibfk_1` FOREIGN KEY (`NFC_ID`) REFERENCES `customer` (`NFC_ID`);

--
-- Constraints for table `subscribes`
--
ALTER TABLE `subscribes`
  ADD CONSTRAINT `subscribes_ibfk_1` FOREIGN KEY (`ServiceID`) REFERENCES `service` (`ServiceID`),
  ADD CONSTRAINT `subscribes_ibfk_2` FOREIGN KEY (`NFC_ID`) REFERENCES `customer` (`NFC_ID`);

--
-- Constraints for table `used`
--
ALTER TABLE `used`
  ADD CONSTRAINT `used_ibfk_1` FOREIGN KEY (`NFC_ID`) REFERENCES `customer` (`NFC_ID`),
  ADD CONSTRAINT `used_ibfk_2` FOREIGN KEY (`ServiceID`) REFERENCES `service` (`ServiceID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
