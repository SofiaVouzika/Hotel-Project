<?php
	header('Location: php/Home.php');
	exit;
?>
Error