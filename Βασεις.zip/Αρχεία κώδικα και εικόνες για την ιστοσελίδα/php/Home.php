<?php
$servername = "localhost";
$username = "root";
$password = "";
$database_name = "Hotel_database";
// Create connection
$conn = new mysqli($servername, $username, $password, $database_name) or die("Unable to connect");

//Check connection
if ($conn->connect_error) {
  die("Η σύνδεση με την βάση δεδομένων απέτυχε: " . $conn->connect_error);
}
?>

<body>

    <ul>
      <li><a href="Home.php">Home Page</a></li>
      <li><a href="Customers.php"> Customers</a></li>
      <li><a href="Services-Charge.php"> Services</a></li>
      <li><a href="Covid.php"> Traceback</a></li>
    </ul>

    <!DOCTYPE html>

<html>
<body>

<style>
      body {
  background-image: url('homepicture.jpg');
}
</style>

<h1 style = "color: white;"> <em>Welcome to our exotic hotel!<em> </h2>
</body>
</html>