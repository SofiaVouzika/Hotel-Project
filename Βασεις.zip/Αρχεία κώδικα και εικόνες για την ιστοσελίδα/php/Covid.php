<?php
$servername = "localhost";
$username = "root";
$password = "";
$database_name = "Hotel_database";
// Create connection
$conn = new mysqli($servername, $username, $password, $database_name) or die("Unable to connect");

//Check connection
if ($conn->connect_error)
{
    die("Η σύνδεση με την βάση δεδομένων απέτυχε: " . $conn->connect_error);
}
?>

<body>

    <ul>
      <li><a href="Home.php">Home Page</a></li>
      <li><a href="Customers.php"> Customers</a></li>
      <li><a href="Services-Charge.php"> Services</a></li>
      <li><a href="Covid.php"> Traceback</a></li>

    </ul>
<h1> 
    Were you tested positive to Covid-19?
</h1>

<table class="content-table">
     <thead>
      <caption><b>Covid-Traceback</b></caption>
      <tr>
        <th> NFC_ID </th>
        <th> Name </th>
        <th> Surname </th>
        <th> RoomName </th>
        <th> Enter date and time </th>
        <th> Exit date and time </th>
        </tr>
    </thead>

    <form class="" action="" method="post">
      <p> Submit the NFC-ID of the tested positive customer: <input type = 'text' name = "NFC_ID" value = ""></p>
      <input type = 'submit' name = 'submit' value = 'Submit'>


      <?php
if (isset($_POST['submit']))
{
    $query = "
       SELECT NFC_ID, Name, Surname, RoomName, EnterTime, ExitTime, RoomID
       FROM Customer
       NATURAL JOIN Visits
       NATURAL JOIN Room
       WHERE NFC_ID = '{$_POST['NFC_ID']}'";

    $result = mysqli_query($conn, $query);

    $rows = array();
    while ($row_result = mysqli_fetch_assoc($result))
    {
        $rows[] = $row_result;
    }

    for ($i = 0;$i < count($rows);$i++)
    {
?>
            <tr>
              <td><?php echo $rows[$i]['NFC_ID'] ?></td>
              <td><?php echo $rows[$i]['Name'] ?></td>
              <td><?php echo $rows[$i]['Surname'] ?></td>
              <td><?php echo $rows[$i]['RoomName'] ?></td>
              <td><?php echo $rows[$i]['EnterTime'] ?></td>
              <td><?php echo $rows[$i]['ExitTime'] ?></td>
            </tr>
            <?php
    }

?>
      </table>
      <br><br>
      <table class="content-table">
      <thead>
      <caption><b>Interracted with</b></caption>
      <tr>
        <th> NFC_ID </th>
        <th> Name </th>
        <th> Surname </th>
        <th> RoomName </th>
        <th> Enter date and time </th>
        <th> Exit date and time </th>
        </tr>
    </thead>

    <?php
    for ($i = 0;$i < count($rows);$i++)
    {
        $query = "
            SELECT NFC_ID, Name, Surname, RoomName, EnterTime, ExitTime
            FROM Customer
            NATURAL JOIN Visits
            NATURAL JOIN Room
            WHERE NFC_ID != '{$_POST['NFC_ID']}'
            AND RoomID = '{$rows[$i]['RoomID']}'
            AND (EnterTime <= '{$rows[$i]['ExitTime']}'
            OR ExitTime >= '{$rows[$i]['EnterTime']}')";

        $result = mysqli_query($conn, $query);

        while ($rows_data = mysqli_fetch_assoc($result))
        {
        ?>
              <tr>
                <td><?php echo $rows_data['NFC_ID'] ?></td>
                <td><?php echo $rows_data['Name'] ?></td>
                <td><?php echo $rows_data['Surname'] ?></td>
                <td><?php echo $rows_data['RoomName'] ?></td>
                <td><?php echo $rows_data['EnterTime'] ?></td>
                <td><?php echo $rows_data['ExitTime'] ?></td>
              </tr>
              <?php
        }
    }
}
?>
    <style>
      body {
  background-image: url('Covid.jpg');
}
</style>
