<?php
$servername = "localhost";
$username = "root";
$password = "";
$database_name = "Hotel_database";
// Create connection
$conn = new mysqli($servername, $username, $password, $database_name) or die("Unable to connect");

//Check connection
if ($conn->connect_error) {
  die("Η σύνδεση με την βάση δεδομένων απέτυχε: " . $conn->connect_error);
}
?>

<body>

    <ul>
      <li><a href="Home.php">Home Page</a></li>
      <li><a href="Customers.php"> Customers</a></li>
      <li><a href="Services-Charge.php"> Services</a></li>
      <li><a href="Covid.php"> Traceback</a></li>

    </ul>

<!DOCTYPE html>

<html>
<body>
<h1 style="color:DarkSlateBlue;"><em> Our Customers </em> </h1> 

  <table class="content-table">
    <thead>
      
      <tr>
        <th> NFC_ID </th>
        <th> Name </th>
        <th> Surname </th>
        <th> Birthdate </th>
        <th> Type of Document </th>
        <th> ID  </th>
        <th> Date of Issue </th>
        <th> Email </th>
        <th> Phone number </th>
      </tr>
    </thead>

    <?php
    $query = "
    SELECT NFC_ID,Name,Surname,BirthDate,IDDocument,TypeOfDocument,DateOfIssue,Email,PhoneNumber
    FROM customer
    NATURAL JOIN Email NATURAL JOIN Phone";
    $result = mysqli_query($conn, $query);
    ?>
    <?php
    while($rows_data = mysqli_fetch_assoc($result))
    {
      ?>
      <tr>
        <td><?php echo $rows_data['NFC_ID'] ?></td>
        <td><?php echo $rows_data['Name'] ?></td>
        <td><?php echo $rows_data['Surname'] ?></td>
        <td><?php echo $rows_data['BirthDate'] ?></td>
        <td><?php echo $rows_data['IDDocument'] ?></td>
        <td><?php echo $rows_data['TypeOfDocument'] ?></td>
        <td><?php echo $rows_data['DateOfIssue'] ?></td>
        <td><?php echo $rows_data['Email'] ?></td>
        <td><?php echo $rows_data['PhoneNumber'] ?></td>
      </tr>
      <?php
    }
    ?>
  </table>

  <style>
      body {
  background-image: url('Customers.jpg');
}
</style>
</body>
</html>

