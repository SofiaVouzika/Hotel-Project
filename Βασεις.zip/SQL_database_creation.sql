CREATE TABLE `customer` (
  `NFC_ID` int(11) NOT NULL,
  `Name` varchar(32) NOT NULL,
  `Surname` varchar(32) NOT NULL,
  `BirthDate` date NOT NULL,
  `IDDocument` varchar(16) NOT NULL,
  `TypeOfDocument` varchar(16) NOT NULL,
  `DateOfIssue` date NOT NULL,

  PRIMARY KEY (`NFC_ID`)
);

CREATE TABLE `email` (
  `Email` varchar(64) NOT NULL,
  `NFC_ID` int(11) NOT NULL,

   PRIMARY KEY (`Email`),
   FOREIGN KEY `NFC_ID` REFERENCES customer(`NFC_ID`)
);

CREATE TABLE `happensin` (
  `ServiceID` int(11) NOT NULL,
  `RoomID` int(11) NOT NULL,

  PRIMARY KEY (`ServiceID`,`RoomID`)
);

CREATE TABLE `hasaccess` (
  `NFC_ID` int(11) NOT NULL,
  `RoomID` int(11) NOT NULL,
  `StartTime` datetime NOT NULL DEFAULT current_timestamp(),
  `EndTime` datetime NOT NULL DEFAULT current_timestamp(),

  FOREIGN KEY `NFC_ID` REFERENCES customer(`NFC_ID`)
);

CREATE TABLE `phone` (
  `PhoneNumber` varchar(16) NOT NULL,
  `NFC_ID` int(11) NOT NULL,

  PRIMARY KEY (`PhoneNumber`),
  FOREIGN KEY `NFC_ID` REFERENCES customer(`NFC_ID`)
);

CREATE TABLE `room` (
  `RoomID` int(11) NOT NULL,
  `RoomName` varchar(16) NOT NULL,
  `Description` varchar(16) NOT NULL,
  `Beds` int(11) NOT NULL DEFAULT 0,

  PRIMARY KEY (`RoomID`)
);

CREATE TABLE `service` (
  `ServiceID` int(11) NOT NULL,
  `ServiceDescription` text NOT NULL,
  `RequiresSubscription` tinyint(1) NOT NULL,

  PRIMARY KEY (`ServiceID`)
);

CREATE TABLE `subscribes` (
  `NFC_ID` int(11) NOT NULL,
  `ServiceID` int(11) NOT NULL,
  `DateTime` datetime NOT NULL DEFAULT current_timestamp(),

  FOREIGN KEY `ServiceID` REFERENCES service(`ServiceID`),
  FOREIGN KEY `NFC_ID` REFERENCES customer(`NFC_ID`)
);

CREATE TABLE `used` (
  `DateTime` datetime NOT NULL DEFAULT current_timestamp(),
  `ServiceID` int(11) NOT NULL,
  `NFC_ID` int(11) NOT NULL,
  `Price` int(11) NOT NULL,
  `Description` text DEFAULT NULL,

  PRIMARY KEY (`DateTime`),
  FOREIGN KEY `NFC_ID` REFERENCES customer(`NFC_ID`),
  FOREIGN KEY `ServiceID` REFERENCES service(`ServiceID`)
);

CREATE TABLE `visits` (
  `NFC_ID` int(11) NOT NULL,
  `RoomID` int(11) NOT NULL,
  `EnterTime` datetime NOT NULL DEFAULT current_timestamp(),
  `ExitTime` datetime DEFAULT NULL,

  PRIMARY KEY (`NFC_ID`,`RoomID`,`EnterTime`);
);